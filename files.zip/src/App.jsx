import React from "react";

const projects = [
  {
    title: "Awesome Project",
    description: "A short description of your project.",
    link: "https://github.com/yourusername/project-repo"
  },
  // Add more projects here
];

const socialLinks = [
  { name: "GitHub", url: "https://github.com/yourusername" },
  { name: "LinkedIn", url: "https://linkedin.com/in/yourusername" },
  // Add more social links here
];

function App() {
  return (
    <div style={styles.container}>
      <header style={styles.header}>
        <img
          src="https://avatars.githubusercontent.com/u/your-github-id?v=4"
          alt="Your Avatar"
          style={styles.avatar}
        />
        <h1>Your Name</h1>
        <p style={styles.subtitle}>Web Developer | Designer | Your Tagline</p>
        <div>
          {socialLinks.map(link => (
            <a
              key={link.name}
              href={link.url}
              style={styles.socialLink}
              target="_blank"
              rel="noopener noreferrer"
            >
              {link.name}
            </a>
          ))}
        </div>
      </header>
      <main>
        <section>
          <h2>About Me</h2>
          <p>
            Write a few sentences about yourself, your background, and what you’re passionate about.
          </p>
        </section>
        <section>
          <h2>Projects</h2>
          <ul style={styles.projectList}>
            {projects.map(project => (
              <li key={project.title} style={styles.projectItem}>
                <a href={project.link} target="_blank" rel="noopener noreferrer">
                  <strong>{project.title}</strong>
                </a>
                <p>{project.description}</p>
              </li>
            ))}
          </ul>
        </section>
        <section>
          <h2>Contact</h2>
          <p>
            Email: <a href="mailto:your.email@example.com">your.email@example.com</a>
          </p>
        </section>
      </main>
      <footer style={styles.footer}>
        &copy; {new Date().getFullYear()} Your Name
      </footer>
    </div>
  );
}

const styles = {
  container: {
    fontFamily: "system-ui, sans-serif",
    margin: "0 auto",
    maxWidth: 700,
    padding: 20,
    color: "#222"
  },
  header: {
    textAlign: "center",
    marginBottom: 40
  },
  avatar: {
    width: 100,
    borderRadius: "50%",
    marginBottom: 16
  },
  subtitle: {
    color: "#555",
    marginTop: -8
  },
  socialLink: {
    margin: "0 10px",
    color: "#0366d6",
    textDecoration: "none",
    fontWeight: "bold"
  },
  projectList: {
    listStyle: "none",
    padding: 0
  },
  projectItem: {
    marginBottom: 20,
    background: "#f9f9f9",
    padding: 16,
    borderRadius: 8
  },
  footer: {
    textAlign: "center",
    marginTop: 40,
    color: "#888",
    fontSize: 14
  }
};

export default App;